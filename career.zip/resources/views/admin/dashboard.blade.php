@extends('admin.partial.app')
@section('content')
    
@endsection
