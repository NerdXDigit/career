
<?php $__env->startSection('title','Opportunitées'); ?>
<?php $__env->startSection('content'); ?>
<section class="layout-pt-lg layout-pb-lg mt-4">
    <div data-anim-wrap class="container">
        <div class="row y-gap-15 justify-between items-center mt-4">
            <div class="col-lg-6">

            <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Toutes les opportunités</h2>

                

            </div>

            </div>

        </div>

        <div class="row y-gap-30 justify-center pt-50">

            <?php $__currentLoopData = $offres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$offre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                <div data-anim-child="slide-up delay-1">

                    <a href="<?php echo e(route('opportunitiespagedetails',$offre->id)); ?>" class="coursesCard -type-1 ">
                        <div class="relative">
                        <div class="coursesCard__image overflow-hidden rounded-8">
                            <img class="w-1/1" src="<?php echo e(asset('offres.png')); ?>" alt="image">
                            <div class="coursesCard__image_overlay rounded-8"></div>
                        </div>
                        <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                        </div>
                        </div>

                        <div class="h-100 pt-15">
                        <div class="d-flex items-center">
                            <div class="text-16 lh-1 fw-500 text-blue-100 "><?php echo e($offre->titre); ?></div>
                        </div>

                        <div class="text-17 lh-15 fw-500 mt-10 text-black"><?php echo e($offre->poste); ?></div>

                        <div class="d-flex x-gap-10 items-center pt-10">

                            <div class="d-flex items-center">
                            <div class="mr-8">
                                <i class="fa-sharp fa-solid fa-location-dot"></i>
                            </div>
                            <div class="text-14 lh-1 text-black"><?php echo e($offre->pays); ?> | <?php echo e($offre->lieu); ?></div>
                            </div>

                            <div class="d-flex items-center">
                            <div class="mr-8">
                                <img src="<?php echo e(asset('img/coursesCards/icons/3.svg')); ?>" alt="icon">
                            </div>
                            <div class="text-14 lh-1 text-black"><?php echo e($offre->niveau); ?></div>
                            </div>

                        </div>
                        <div class="d-flex x-gap-10 items-center justify-between my-4 pt-10">

                            <div class="d-flex items-center">
                            <h3 class="lh-1"><?php echo e($offre->entreprise); ?></h3>
                            </div>

                            <div class="d-flex items-center">
                            <div class="mr-8">
                                <img src="<?php echo e(asset('img/coursesCards/icons/2.svg')); ?>" alt="icon">
                            </div>
                            <h5 class="text-14 lh-1 text-black"><?php echo e($offre->deadline); ?></h5>
                            </div>

                        </div>

                        </div>
                    </a>

                </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\NerdX\career\resources\views/opportunities.blade.php ENDPATH**/ ?>