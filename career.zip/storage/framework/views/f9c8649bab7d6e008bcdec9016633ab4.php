  <!-- Dashboard -->
  <li class="menu-item active">
    <a href="<?php echo e(url('espace/client')); ?>" class="menu-link">
      <i class="menu-icon tf-icons bx bx-home-circle"></i>
      <div data-i18n="Analytics">Dashboard</div>
    </a>
  </li>
 <!-- Layouts -->
 <li class="menu-item open">
    <a href="" class="menu-link menu-toggle">
      <i class="menu-icon tf-icons bx bx-layout"></i>
      <div data-i18n="Layouts">Espaces Client</div>
    </a>

    <ul class="menu-sub">
      <li class="menu-item">
        <a href="<?php echo e(url('espace/client/souscription')); ?>" class="menu-link">
          <div data-i18n="Without menu">Mes Souscriptions</div>
        </a>
      </li>
      
    </ul>
  </li><?php /**PATH D:\NerdX\career\resources\views/user/navbar.blade.php ENDPATH**/ ?>