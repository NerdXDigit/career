<?php $__env->startSection('title','Connexion'); ?>
<?php $__env->startSection('content'); ?>
<section class="form-page js-mouse-move-container">
    <div class="form-page__img bg-dark-1">
      <div class="form-page-composition">
        <h1 class="text-white mt-4">Se Connecter</h1>
      </div>
    </div>

    <div class="form-page__content lg:py-50">
      <div class="container">
        <div class="row justify-center items-center">
          <div class="col-xl-6 col-lg-8">
            <div class="px-50 py-50 md:px-25 md:py-25 bg-white shadow-1 rounded-16">
              <h3 class="text-30 lh-13 text-center">Connexion</h3>
              <p class="mt-10 text-center">Vous n'avez pas un compte ? <a href=" <?php echo e(route('registerpage')); ?> " class="text-purple-1">S'inscrire gratuitement</a></p>

              <form class="contact-form respondForm__form row y-gap-20 pt-30" method="POST" action="<?php echo e(route('loginaction')); ?>">
                  <?php echo e(csrf_field()); ?>

                <div class="col-12">
                  <label class="text-16 lh-1 fw-500 text-dark-1 mb-10">Email</label>
                  <input type="email" name="email" placeholder="Email">
                    <?php if($errors->has('email')): ?>
                      <div style="color: #f1416c !important"><?php echo e($errors->first('email')); ?> </div>
                    <?php endif; ?>
                </div>
                <div class="col-12">
                  <label class="text-16 lh-1 fw-500 text-dark-1 mb-10">Mot de passe</label>
                  <input type="password" name="password" placeholder="Mot de passe">
                    <?php if($errors->has('password')): ?>
                      <div style="color: #f1416c !important"><?php echo e($errors->first('password')); ?> </div> 
                    <?php endif; ?>
                </div>
                <div class="col-12">
                  <button type="submit" name="submit" id="submit" class="button -md -dark-1 text-white fw-500 w-1/1">
                    Se Connecter
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.compte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\NerdX\career\resources\views/login.blade.php ENDPATH**/ ?>