@extends('offreur.partial.app')
@section('content')
    
@endsection
